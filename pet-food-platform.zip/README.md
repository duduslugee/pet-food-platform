# Plataforma de Venda de Ração para Animais

Plataforma desenvolvida com microserviços em Java (Spring Boot) e frontend em React para venda de ração para animais.

## Arquitetura
- **catalog-service**: Gerencia o catálogo de produtos (rações).
- **user-service**: Gerencia usuários (cadastro, login).
- **order-service**: Gerencia pedidos (criação, consulta).
- **payment-service**: Simula o processamento de pagamento.
- **frontend**: Interface em React para interação do usuário.

## Pré-requisitos
- Java 17
- Maven
- Node.js 18
- Docker e Docker Compose

## Como Executar
1. Clone o repositório:
   ```bash
   git clone <URL_DO_REPOSITORIO>
   ```

2. Compile os microserviços:
    ```bash
    cd catalog-service && mvn clean package
    cd ../user-service && mvn clean package
    cd ../order-service && mvn clean package
    cd ../payment-service && mvn clean package
    ```
3. Suba os serviços:
    ```bash
    cd .. && docker-compose up --build
    ```
4. Acesse o frontend em http://localhost:3000.

## Endpoints
 - **Catálogo de Produtos (porta 8081):**
    - GET /products: Lista todos os produtos.
    - GET /products/{id}: Detalhes de um produto.
    - POST /products: Cria um novo produto.
 - **Usuários (porta 8082):**
    - POST /users/register: Cadastra um usuário.
    - POST /users/login: Faz login.
    - GET /users/{id}: Detalhes do usuário.
 - **Pedidos (porta 8083):**
    - POST /orders: Cria um pedido.
    - GET /orders/user/{userId}: Lista pedidos do usuário.
 - **Pagamento (porta 8084):**
    - POST /payments: Processa o pagamento (simulado).

## Licença
MIT