import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function ProductList({ cart, setCart }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8081/products')
      .then((res) => res.json())
      .then((data) => setProducts(data))
      .catch((err) => console.error(err));
  }, []);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div className="product-list">
      <h2>Produtos Disponíveis</h2>
      {products.map((product) => (
        <div key={product.id} className="product-card">
          <h3>{product.name}</h3>
          <p>Preço: R${product.price}</p>
          <Link to={`/product/${product.id}`}>Ver Detalhes</Link>
          <button onClick={() => addToCart(product)}>Adicionar ao Carrinho</button>
        </div>
      ))}
    </div>
  );
}

export default ProductList;